a = 0
print(1, 0)

for i in range(99):
    a = (a + 3) % 13
    print(i+2, a)
